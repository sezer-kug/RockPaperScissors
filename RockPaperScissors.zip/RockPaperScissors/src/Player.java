
public abstract class Player {

    public Player() {
    }
    //Abstract play method to be extended from the subclasses
    public abstract char play();
}
